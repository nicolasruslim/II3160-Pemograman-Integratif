<?php

class Mock_Libraries_Upload extends CI_Upload {}