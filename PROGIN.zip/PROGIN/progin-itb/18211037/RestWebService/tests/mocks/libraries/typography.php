<?php

class Mock_Libraries_Typography extends CI_Typography {}