<?php

class Mock_Core_Benchmark extends CI_Benchmark {}