#######
Credits
#######

CodeIgniter was originally developed by `Rick
Ellis <http://www.ellislab.com/>`_ (CEO of `EllisLab,
Inc. <http://ellislab.com/>`_). The framework was written for
performance in the real world, with many of the class libraries,
helpers, and sub-systems borrowed from the code-base of
`ExpressionEngine <http://www.expressionengine.com/>`_.

It is currently developed and maintained by the ExpressionEngine
Development Team.
Bleeding edge development is spearheaded by the handpicked contributors
of the Reactor Team.

A hat tip goes to Ruby on Rails for inspiring us to create a PHP
framework, and for bringing frameworks into the general consciousness of
the web community.